/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package feria121;
import java.util.Date;
import java.util.List;

/**
 *
 * @author luis
 */

public class Consulta {
    private String diagnostico;
    private String descripcion;
    private List<Tratamiento> tratamientos;
    private Medico medico;
    private Usuario usuario;
    private Date fecha;

    public Consulta(String diagnostico, String descripcion, List<Tratamiento> tratamientos, Medico medico, Usuario usuario, Date fecha) {
        this.diagnostico = diagnostico;
        this.descripcion = descripcion;
        this.tratamientos = tratamientos;
        this.medico = medico;
        this.usuario = usuario;
        this.fecha = fecha;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Tratamiento> getTratamientos() {
        return tratamientos;
    }

    public Medico getMedico() {
        return medico;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Date getFecha() {
        return fecha;
    }
}
