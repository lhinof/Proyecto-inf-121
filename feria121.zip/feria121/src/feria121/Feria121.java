/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package feria121;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 *
 * @author luis
 */
public class Feria121 {
    public static void main(String[] args) {
            FeriaDeSalud feria = new FeriaDeSalud("Feria de Salud La Paz", new Date(125, 5, 11), "La Paz, Bolivia", "Salud Pública");

            Paciente p1 = new Paciente("Ana", 30, "Femenino", List.of("COVID-19", "Influenza"), null);
            Paciente p2 = new Paciente("Pedro", 45, "Masculino", List.of("Hepatitis B"), null);
            Paciente p3 = new Paciente("Luis", 60, "Masculino", null, null);
            Paciente p4 = new Paciente("Maria", 25, "Femenino", List.of("COVID-19"), null);
            Paciente p5 = new Paciente("Carlos", 50, "Masculino", null, null);

            Medico m1 = new Medico("Jorge", 40, "Masculino", "Pediatría");
            Medico m2 = new Medico("Rocío", 38, "Femenino", "Cardiología");

            Tratamiento t1 = new Tratamiento("Antibióticos", "Tratamiento con antibióticos para infecciones");
            Tratamiento t2 = new Tratamiento("Terapia Física", "Sesiones de terapia para recuperación");
            Tratamiento t3 = new Tratamiento("Control de presión", "Monitoreo y medicación para hipertensión");
            Tratamiento t4 = new Tratamiento("Vacunación", "Aplicación de vacunas preventivas");
            Tratamiento t5 = new Tratamiento("Consejería nutricional", "Asesoría sobre alimentación saludable");

            List<Tratamiento> tratamientos1 = new ArrayList<>();
            tratamientos1.add(t1);
            Consulta c1 = new Consulta("Infección Respiratoria", "Paciente con tos y fiebre", tratamientos1, m1, p1, new Date(125, 5, 10));

            List<Tratamiento> tratamientos2 = new ArrayList<>();
            tratamientos2.add(t3);
            Consulta c2 = new Consulta("Hipertensión", "Paciente con presión alta", tratamientos2, m2, p2, new Date(125, 5, 9));

            List<Tratamiento> tratamientos3 = new ArrayList<>();
            tratamientos3.add(t5);
            Consulta c3 = new Consulta("Chequeo General", "Revisión anual", tratamientos3, m1, p3, new Date(125, 5, 8));

            List<Tratamiento> tratamientos4 = new ArrayList<>();
            tratamientos4.add(t4);
            Consulta c4 = new Consulta("Vacunación COVID-19", "Aplicación de refuerzo", tratamientos4, m1, p4, new Date(125, 5, 7));

            List<Tratamiento> tratamientos5 = new ArrayList<>();
            tratamientos5.add(t2);
            Consulta c5 = new Consulta("Dolor muscular", "Paciente con dolor lumbar", tratamientos5, m2, p5, new Date(125, 5, 6));

           
            feria.registrarUsuario(p1);
            feria.registrarUsuario(p2);
            feria.registrarUsuario(p3);
            feria.registrarUsuario(p4);
            feria.registrarUsuario(p5);

            feria.medicos.add(m1);
            feria.medicos.add(m2);

            feria.consultas.add(c1);
            feria.consultas.add(c2);
            feria.consultas.add(c3);
            feria.consultas.add(c4);
            feria.consultas.add(c5);

            System.out.println("\n--- Feria de Salud La Paz - Participantes ---");
            feria.mostrarUsuarios();

            System.out.println("\n--- Médicos Registrados ---");
            for (Medico medico : feria.medicos) {
                medico.mostrarInfo();
                System.out.println("---");
            }

            System.out.println("\n--- Consultas Registradas ---");
            for (Consulta consulta : feria.consultas) {
                System.out.println("Fecha: " + consulta.getFecha());
                System.out.println("Paciente: " + consulta.getUsuario().nombre);
                System.out.println("Médico: " + consulta.getMedico().nombre);
                System.out.println("Diagnóstico: " + consulta.getDiagnostico());
                System.out.println("Tratamiento: " + (consulta.getTratamientos().isEmpty() ? "Ninguno" : consulta.getTratamientos().get(0).getNombre()));
                System.out.println("---");
            }
       }
}
