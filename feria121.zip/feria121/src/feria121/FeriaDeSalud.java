/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package feria121;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luis
 */

public class FeriaDeSalud {
    private String nombre;
    private java.util.Date fecha;
    private String lugar;
    private String tipo;

    public List<Usuario> usuarios;
    public List<Medico> medicos;
    public List<Consulta> consultas;

    public FeriaDeSalud(String nombre, java.util.Date fecha, String lugar, String tipo) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.lugar = lugar;
        this.tipo = tipo;
        this.usuarios = new ArrayList<>();
        this.medicos = new ArrayList<>();
        this.consultas = new ArrayList<>();
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void mostrarUsuarios() {
        System.out.println("\nLista de participantes registrados en '" + nombre + "':\n");
        for (Usuario usuario : usuarios) {
            usuario.mostrarInfo();
            System.out.println("---");
        }
    }

}
