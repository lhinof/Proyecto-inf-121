/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package feria121;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luis
 */

public class Paciente extends Usuario {
    private List<String> historialMedico;
    private String codigo; 

    public Paciente(String nombre, int edad, String genero) {
        super(nombre, edad, genero);
        this.historialMedico = new ArrayList<>();
    }

    public Paciente(String nombre, int edad, String genero, List<String> vacunas, List<String> historialMedico) {
        super(nombre, edad, genero, vacunas);
        this.historialMedico = historialMedico != null ? historialMedico : new ArrayList<>();
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Historial médico: " + historialMedico);
        System.out.println("Código: " + codigo);
    }
}
