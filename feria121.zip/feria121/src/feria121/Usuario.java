/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package feria121;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author luis
 */

public class Usuario extends Persona {
    protected List<String> vacunas;

    public Usuario(String nombre, int edad, String genero) {
        super(nombre, edad, genero);
        this.vacunas = new ArrayList<>();
    }

    public Usuario(String nombre, int edad, String genero, List<String> vacunas) {
        super(nombre, edad, genero);
        this.vacunas = vacunas != null ? vacunas : new ArrayList<>();
    }

    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Vacunas: " + vacunas);
    }
}
