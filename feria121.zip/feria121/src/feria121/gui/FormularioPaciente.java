
package feria121.gui;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import feria121.Paciente;

public class FormularioPaciente extends javax.swing.JFrame {

    private JTextField txtNombre;
    private JTextField txtEdad;
    private JTextField txtGenero;
    private JTextField txtVacunas;
    private JButton btnGuardar;

    public FormularioPaciente() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Registro de Paciente");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 30, 80, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(120, 30, 200, 25);
        add(txtNombre);

        JLabel lblEdad = new JLabel("Edad:");
        lblEdad.setBounds(30, 70, 80, 25);
        add(lblEdad);

        txtEdad = new JTextField();
        txtEdad.setBounds(120, 70, 200, 25);
        add(txtEdad);

        JLabel lblGenero = new JLabel("Género:");
        lblGenero.setBounds(30, 110, 80, 25);
        add(lblGenero);

        txtGenero = new JTextField();
        txtGenero.setBounds(120, 110, 200, 25);
        add(txtGenero);

        JLabel lblVacunas = new JLabel("Vacunas:");
        lblVacunas.setBounds(30, 150, 80, 25);
        add(lblVacunas);

        txtVacunas = new JTextField();
        txtVacunas.setBounds(120, 150, 200, 25);
        add(txtVacunas);

        btnGuardar = new JButton("Guardar Paciente");
        btnGuardar.setBounds(120, 200, 160, 30);
        add(btnGuardar);

        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
    }

    private void btnGuardarActionPerformed(ActionEvent evt) {
        String nombre = txtNombre.getText();
        int edad = 0;
        try {
            edad = Integer.parseInt(txtEdad.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Edad inválida. Debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String genero = txtGenero.getText();
        String vacunasStr = txtVacunas.getText();
        List<String> vacunas = new ArrayList<>();
        if (!vacunasStr.isEmpty()) {
            for (String v : vacunasStr.split(",")) {
                vacunas.add(v.trim());
            }
        }

        Paciente paciente = new Paciente(nombre, edad, genero, vacunas, null);

        JOptionPane.showMessageDialog(this, "Paciente registrado:\n" + paciente.getNombre());
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new FormularioPaciente().setVisible(true);
        });
    }
}
