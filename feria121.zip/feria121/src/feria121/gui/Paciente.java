
package feria121;

import java.util.List;

public class Paciente {
    private String nombre;
    private int edad;
    private String genero;
    private List<String> vacunas;
    private Object otro;

    public Paciente(String nombre, int edad, String genero, List<String> vacunas, Object otro) {
        this.nombre = nombre;
        this.edad = edad;
        this.genero = genero;
        this.vacunas = vacunas;
        this.otro = otro;
    }

    public String getNombre() {
        return nombre;
    }

    // Puedes agregar más getters y setters si lo necesitas
}
